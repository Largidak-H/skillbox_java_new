public class Loader
{
    public static void main(String[] args) {
        Integer dimaAge = 25;
        Integer mishaAge = 30;
        Integer vasyaAge = 40;

        Integer max;
        Integer min;
        Integer middle;

        if (dimaAge == mishaAge)
        {
            if (dimaAge == vasyaAge)
            {
                //1
                max = min = middle = dimaAge;
            }
            else
            {
                middle = dimaAge;
                if (dimaAge > vasyaAge)
                {
                    //2
                    max = dimaAge;
                    min = vasyaAge;
                }
                else
                {
                    //3
                    max = vasyaAge;
                    min = dimaAge;
                }
            }
        }
        else
        {
            if (dimaAge == vasyaAge)
            {
                middle = dimaAge;
                if (dimaAge > mishaAge)
                {
                    //4
                    max = dimaAge;
                    min = mishaAge;
                }
                else
                {
                    //5
                    max = mishaAge;
                    min = dimaAge;
                }
            }
            else
            {
                if (mishaAge == vasyaAge)
                {
                    middle = mishaAge;
                    if (mishaAge > dimaAge)
                    {
                        //6
                        max = mishaAge;
                        min = dimaAge;
                    }
                    else
                    {
                        //7
                        max = dimaAge;
                        min = mishaAge;
                    }
                }
                else
                {
                    if (dimaAge > mishaAge)
                    {
                        if (dimaAge > vasyaAge)
                        {
                            max = dimaAge;
                            if (mishaAge > vasyaAge)
                            {
                                //8
                                middle = mishaAge;
                                min = vasyaAge;
                            }
                            else
                            {
                                //9
                                middle = vasyaAge;
                                min = mishaAge;
                            }
                        }
                        else
                        {
                            //10
                            max = vasyaAge;
                            middle = dimaAge;
                            min = mishaAge;
                        }
                    }
                    else
                    {
                        if (dimaAge > vasyaAge)
                        {
                            //11
                            max = mishaAge;
                            middle = dimaAge;
                            min = vasyaAge;
                        }
                        else
                        {
                            min = dimaAge;
                            if (mishaAge > vasyaAge)
                            {
                                //12
                                max = mishaAge;
                                middle = vasyaAge;
                            }
                            else
                            {
                                //13
                                max = vasyaAge;
                                middle = mishaAge;
                            }
                        }
                    }
                }
            }
        }
        System.out.println("Minimal age: " + min);
        System.out.println("Middle age: " + middle);
        System.out.println("Maximum age: " + max);
    }
}
