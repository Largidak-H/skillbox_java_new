public enum Color {
    BLACK,
    WHITE,
    RED,
    SPOTTED
}
