
public class Cat
{
    private double originWeight;
    private double weight;

    public static final double MIN_WEIGHT = 1000.;
    public static final double MAX_WEIGHT = 9000.;
    public static final int EYES_COUNT = 2;

    private double amountEaten;

    private static int count = 0;

    public Cat()
    {
        weight = 1500.0 + 3000.0 * Math.random();
        originWeight = weight;
        amountEaten = 0;
        count++;
    }

    public Cat(double weight)
    {
        this();
        this.weight = weight;
        count++;
    }

    public Cat(Cat cat)
    {
        this();
        weight = cat.weight;
        originWeight = cat.originWeight;
        amountEaten = cat.amountEaten;
        count++;
    }

    public double getEaten()
    {
        return amountEaten;
    }

    public void pee(Double amount)
    {
        weight = weight- amount;
        System.out.println("/Noise from tray/");
    }

    public static  int getCount() {
        return count;
    }

    public void meow()
    {
        if ((MIN_WEIGHT < weight) && (weight < MAX_WEIGHT))
        {
            weight = weight - 1;
            System.out.println("Meow");
        }
        else {
            System.out.println("Error. Cat is not exist");
        }
    }

    public void feed(Double amount)
    {
        if ((MIN_WEIGHT < weight) && (weight < MAX_WEIGHT))
        {
            amountEaten = amount;
            weight = weight + amount;
        }
        else {
            System.out.println("Error. Cat is not exist");
        }
    }

    public void drink(Double amount)
    {
        if ((MIN_WEIGHT < weight) && (weight < MAX_WEIGHT))
        {
            weight = weight + amount;
        }
        else {
            System.out.println("Error. Cat is not exist");
        }
    }

    public Double getWeight()
    {
        return weight;
    }

    public String getStatus()
    {
        if(weight < MIN_WEIGHT) {
            count--;
            return "Dead";
        }
        else if(weight > MAX_WEIGHT) {
            count--;
            return "Exploded";
        }
        else if(weight > originWeight) {
            return "Sleeping";
        }
        else {
            return "Playing";
        }
    }
}